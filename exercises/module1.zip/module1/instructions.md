You have to get the same look and feel than the picture included. For that, the only properties you must use are color and background-color. You shouldn't have to modify the html markup for nothing more than to add the styles.

Remember, this exercise is about selectors, not properties.

You have two stylesheets attached, but you can only include one link statement in the html.

Good luck!

