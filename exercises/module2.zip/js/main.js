var $item = $('.item'),
  $offscreen = $('#offscreen'),
  $rule = $('.rule'),
  $selector = $('.selector'),
  $specifity = $('.specificity'),
  $solution = $('.solution'),
  $button = $('.button'),
  update, counter = 0, rules = [],
  state = "close", self = this;

rules = ['h2 span',
         'body .row h1',
         '.block p',
         '#navigation a',
         '#navigation ul li a',
         '#navigation ul li a:hover',
         'ul li:first-child span',
         'ul li:first-child a:hover',
         '#first + .row .block span',
         '.row:first-child ~ .row > span',
         '.block a:hover:before'];

var createItem = function(selector, $prev) {
  var $specificityA = $specifity.find('.type-a'),
      $specificityB = $specifity.find('.type-b'),
      $specificityC = $specifity.find('.type-c'),
      $specificityD = $specifity.find('.type-d');

  var update = function(e) {
    var input = $rule.text(),
      result,
      specificity,
      highlightedSelector,
      i, len, part, text1, text2, text3;

    result = SPECIFICITY.calculate(input);

    if (result.length === 0) {
      $selector.text(' ');
      $specificityA.text('0');
      $specificityB.text('0');
      $specificityC.text('0');
      $specificityD.text('0');
      return;
    }

    result = result[0];
    specificity = result.specificity.split(',');
    $specificityA.text(specificity[0]);
    $specificityB.text(specificity[1]);
    $specificityC.text(specificity[2]);
    $specificityD.text(specificity[3]);

    highlightedSelector = result.selector;
    for (i = result.parts.length - 1; i >= 0; i -= 1) {
      part = result.parts[i];
      text1 = highlightedSelector.substring(0, part.index);
      text2 = highlightedSelector.substring(part.index, part.index + part.length);
      text3 = highlightedSelector.substring(part.index + part.length);
      highlightedSelector = text1 + '<span class="type-' + part.type + '">' + text2 + '</span>' + text3;
    }
    $selector.html(highlightedSelector);
  };
  
  $rule.html(selector);
  update();
};

var delay = function(status){

  if (counter > rules.length - 1) return;

  setTimeout(function(){
    state = status;
    if (status == "close"){
      $button.html('SEE THE SOLUTION');
      counter++;
      createItem(rules[counter]);
    }
  }.bind(self), 800);
};

$button.on('click', function(e){

  e.preventDefault();

  if (state == "middle") return;

  if (state == "close") {
    $item.addClass('resolved');
    $solution.removeClass('is-hidden');
    state = "middle";
    $(this).html('NEXT CHALLENGE');
    delay("open");
  } else {
    $solution.addClass('is-hidden');
    $item.removeClass('resolved');
    state = "middle";
    if (counter == rules.length - 1){
      $rule.html("You are the boss!");
      $button.html('CONGRATULATIONS!');
    } else {
      delay("close");
    }
  }
});

createItem(rules[counter]);

